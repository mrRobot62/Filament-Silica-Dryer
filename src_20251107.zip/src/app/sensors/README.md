# sensors/
Hier kommen spätere Sensor-Implementierungen rein (z. B. MAX31856, BME280, ...).