#pragma once
#include "../pins.h"
#include <RotarySwitch.h>

static RotarySwitch rs(ENC_PIN_A, ENC_PIN_B, ENC_PIN_SW);
static long lastPosShown = LONG_MIN;
