/*
 * FILE: ui.h
 * AUTHOR: LVGL Visual Architect (Generated)
 * DESCRIPTION: Header file for the generated UI.
 *              Declares UI elements and the main initialization function.
 */

#ifndef UI_H
#define UI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

// Screen externs
extern lv_obj_t *ui_main_screen;

// Widget externs
extern lv_obj_t *ui_rolType;


// Function declarations for event callbacks
void ui_init(void);
void on_click_rolType(lv_event_t * e);
void on_change_rolType(lv_event_t * e);
void on_click_btnStart(lv_event_t * e);
void on_click_btnCancel(lv_event_t * e);


#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /*UI_H*/
