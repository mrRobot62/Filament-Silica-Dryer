/*
 * FILE: ui.c
 * AUTHOR: LVGL Visual Architect (Generated)
 * DESCRIPTION: Implementation of the UI. This file should NOT be modified
 *              by the user, as it will be regenerated.
 */

#include "ui.h"

/////////////////////
// EVENT FORWARD DECLARATIONS
/////////////////////
void on_rolType_Clicked(lv_event_t * e);
void on_rolType_Focused(lv_event_t * e);
void on_rolType_ValueChanged(lv_event_t * e);
void on_bntStart_Clicked(lv_event_t * e);
void on_bntStart_Focused(lv_event_t * e);
void on_bntCancel_Focused(lv_event_t * e);
void on_bntCancel_Clicked(lv_event_t * e);

/////////////////////
// ASSETS
/////////////////////
// LV_IMG_DECLARE(...)

/////////////////////
// SCREEN DEFINITIONS
/////////////////////
lv_obj_t *ui_main_screen;

/////////////////////
// WIDGET DEFINITIONS
/////////////////////
lv_obj_t *ui_lblType;
lv_obj_t *ui_rolType;
lv_obj_t *ui_bntStart;
lv_obj_t *ui_bntCancel;

/////////////////////
// SCREEN FUNCTIONS
/////////////////////
void ui_main_screen_init(void) {
    ui_main_screen = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_main_screen, LV_OBJ_FLAG_SCROLLABLE);

    // ------------------------------------------
    // --- lblType Setup ---
    // ------------------------------------------
    ui_lblType = lv_label_create(ui_main_screen);
    lv_label_set_text(ui_lblType, "Type:");
    lv_obj_set_width(ui_lblType, 50);
    lv_obj_set_height(ui_lblType, 30);
    lv_obj_align(ui_lblType, LV_ALIGN_TOP_LEFT, 5, 10);
    lv_obj_set_style_text_color(ui_lblType, lv_color_hex(0xF9FAFB), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui_lblType, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN | LV_STATE_DEFAULT);
    // To use custom font size, enable a font in lv_conf.h and apply it here.
    // lv_obj_set_style_text_font(ui_lblType, &lv_font_montserrat_12, LV_PART_MAIN | LV_STATE_DEFAULT);

    // ------------------------------------------
    // --- rolType Setup ---
    // ------------------------------------------
    ui_rolType = lv_roller_create(ui_main_screen);
    lv_roller_set_options(ui_rolType, "PLA-Basic\nPLA+\nPLA-HS\nPETG\nPETG-HS\nASA\nTPU", LV_ROLLER_MODE_NORMAL);
    lv_roller_set_selected(ui_rolType, 1, LV_ANIM_OFF);
    lv_obj_set_width(ui_rolType, 150);
    lv_obj_set_height(ui_rolType, 35);
    lv_obj_align(ui_rolType, LV_ALIGN_TOP_LEFT, 50, 5);
    lv_obj_set_style_bg_color(ui_rolType, lv_color_hex(0x374151), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui_rolType, lv_color_hex(0xF9FAFB), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui_rolType, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN | LV_STATE_DEFAULT);
    // To use custom font size, enable a font in lv_conf.h and apply it here.
    // lv_obj_set_style_text_font(ui_rolType, &lv_font_montserrat_14, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_add_event_cb(ui_rolType, on_rolType_Clicked, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(ui_rolType, on_rolType_Focused, LV_EVENT_FOCUSED, NULL);
    lv_obj_add_event_cb(ui_rolType, on_rolType_ValueChanged, LV_EVENT_VALUE_CHANGED, NULL);

    // ------------------------------------------
    // --- bntStart Setup ---
    // ------------------------------------------
    ui_bntStart = lv_btn_create(ui_main_screen);
    lv_obj_t* ui_bntStart_label = lv_label_create(ui_bntStart);
    lv_label_set_text(ui_bntStart_label, "START");
    lv_obj_center(ui_bntStart_label);
    lv_obj_set_width(ui_bntStart, 80);
    lv_obj_set_height(ui_bntStart, 25);
    lv_obj_align(ui_bntStart, LV_ALIGN_TOP_LEFT, 230, 10);
    lv_obj_set_style_bg_color(ui_bntStart, lv_color_hex(0x374151), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui_bntStart, lv_color_hex(0xF9FAFB), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui_bntStart, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN | LV_STATE_DEFAULT);
    // To use custom font size, enable a font in lv_conf.h and apply it here.
    // lv_obj_set_style_text_font(ui_bntStart, &lv_font_montserrat_12, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_add_event_cb(ui_bntStart, on_bntStart_Clicked, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(ui_bntStart, on_bntStart_Focused, LV_EVENT_FOCUSED, NULL);

    // ------------------------------------------
    // --- bntCancel Setup ---
    // ------------------------------------------
    ui_bntCancel = lv_btn_create(ui_main_screen);
    lv_obj_t* ui_bntCancel_label = lv_label_create(ui_bntCancel);
    lv_label_set_text(ui_bntCancel_label, "Cancel");
    lv_obj_center(ui_bntCancel_label);
    lv_obj_set_width(ui_bntCancel, 80);
    lv_obj_set_height(ui_bntCancel, 25);
    lv_obj_align(ui_bntCancel, LV_ALIGN_TOP_LEFT, 230, 40);
    lv_obj_set_style_bg_color(ui_bntCancel, lv_color_hex(0x374151), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui_bntCancel, lv_color_hex(0xF9FAFB), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui_bntCancel, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN | LV_STATE_DEFAULT);
    // To use custom font size, enable a font in lv_conf.h and apply it here.
    // lv_obj_set_style_text_font(ui_bntCancel, &lv_font_montserrat_14, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_add_event_cb(ui_bntCancel, on_bntCancel_Focused, LV_EVENT_FOCUSED, NULL);
    lv_obj_add_event_cb(ui_bntCancel, on_bntCancel_Clicked, LV_EVENT_CLICKED, NULL);

    // ------------------------------------------
    // --- 
    // ------------------------------------------


}


/////////////////////
// MAIN UI FUNCTION
/////////////////////
void ui_init(void) {
    ui_main_screen_init();
    lv_disp_load_scr(ui_main_screen);
}
